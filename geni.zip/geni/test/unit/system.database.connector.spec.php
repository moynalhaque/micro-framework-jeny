<?php

xdescribe('database\\connector (TODO: Write tests)', function () {

});
