<?php

return [
    'url'      => '/geni',
    'index'    => '',
    'timezone' => 'UTC',
    'key'      => 'Fqf5HPDXyiptkisxkrWiEesp8cb6caIB',
    'language' => 'en_GB',
    'encoding' => 'UTF-8'
];
