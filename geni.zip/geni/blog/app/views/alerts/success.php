	
	<div class='success'><div class='alert alert-success'>
	<i class='fa fa-check-circle'></i> 
		<?= $this->encodeHTML($success);?>
	</div></div>