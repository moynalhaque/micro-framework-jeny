<?php echo $header; ?>

  <header class="wrap">
    <h1>Plugins</h1>
  </header>

  <section class="wrap">
    <p class="empty">
      <span class="icon"></span> Soon.
    </p>
  </section>

<?php echo $footer; ?>
