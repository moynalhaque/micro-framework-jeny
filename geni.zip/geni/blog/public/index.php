<?php



require  '../vendor/autoload.php';



define('BASE_DIR', str_replace("\\", "/", dirname(__DIR__)));
define('IMAGES',   str_replace("\\", "/", __DIR__) . "/img/");
define('APP',  BASE_DIR . "/app/");



Handler::register();



Session::init();



$app = new App();

// Config::set('root', $app->request->root());
define('PUBLIC_ROOT', $app->request->root());


$app->run();