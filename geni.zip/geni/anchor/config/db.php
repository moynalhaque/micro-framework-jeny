<?php

return [
    'default'     => 'mysql',
    'prefix'      => 'r_',
    'connections' => [
        'mysql' => [
            'driver'   => 'mysql',
            'hostname' => '127.0.0.1',
            'port'     => '3306',
            'username' => 'root',
            'password' => '',
            'database' => 'miniphp_68dozftn',
            'charset'  => 'utf8mb4'
        ]
    ]
];
