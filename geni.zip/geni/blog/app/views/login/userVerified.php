

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">User Verification</h3>
                    </div>
                    <div class="panel-body">
                        <div class="alert alert-success">
							<i class="fa fa-check-circle"></i> <strong>Congratulations!</strong> Your email has been activated. 
								Please <a href="<?= PUBLIC_ROOT; ?>">Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

