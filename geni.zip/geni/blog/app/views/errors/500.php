
        <!-- Page Content -->
        <div id="page-wrapper" style="min-height: 294px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12" style="text-align:center; font-family:'Trebuchet MS', Helvetica, sans-serif;">
                        <h1 class="page-header" style="font-size: 80px;">500</h1>
                        <h1 class="page-header">Oops, we are sorry but our system encountered an internal error<br>But do not worry, we are on it</h1>
                    </div>
					<hr>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->