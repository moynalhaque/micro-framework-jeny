<?php

xdescribe('database\\query (TODO: Write tests)', function () {

});
